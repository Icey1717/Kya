#pragma once
#include <stdio.h>

int processPss(FILE* pss, FILE* pout, FILE* sout, FILE* aout, FILE* vout, char* name);